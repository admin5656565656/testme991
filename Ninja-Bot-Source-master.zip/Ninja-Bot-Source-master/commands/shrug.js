const Discord = require("discord.js");
const bot = new Discord.Client();
exports.run = (client, message, args) => {
      message.channel.send("¯\\_(ツ)_/¯")
}