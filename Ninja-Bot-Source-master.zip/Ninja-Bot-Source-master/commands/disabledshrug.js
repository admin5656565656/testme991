const Discord = require("discord.js");
const bot = new Discord.Client();
exports.run = async (client, message, args) => {
    message.channel.send("¯\_(ツ)_/¯");
}
